# VPS-MX By Kalix1 ( MOD NEW-ULTIMATE )
```
* UPDATE 17/07/2021 - Proyecto Descontinuado
* VPS-MX (Final Version 8.4e)
```
![logo](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/blob/master/NEW-ULTIMATE-VPS-MX-8.0/Imagenes/NEW-ULTIMATE-VPS-MX-8.4.png)

```
# SCRIPT VPS�MX � Script Manager de VPS

ESTE ES UN SCRIPT PARA LA ADMINISTRACION DE CUENTAS DE TIPO:

-SSH
-SSL
-DROPBEAR
-OPENVPN
-SHADOWSOCK, SHADOWSOCK-liv, SHADOWSOCKR (PERSONAL)
-V2RAY (PERSONAL)
-PANEL TROJAN
-IODINE
-BRAINFUCK PSIPHON PRO GO
-PROXYS (PYTHON-PUB,PYTHON-SEG,PYTHON-DIR,TCP OVER,SQUID)

MONITOREO DE:

-USUARIOS SSH/DROPBEAR/SSL/OPENVPN
-TIEMPO
-EXPIRACION
-MONITOR DE PROTOCOLOS

BOT MANAGER:

-CONTROLA EL USO DE TUS CUENTAS SSH DESDE UN BOT DE TELEGRAM
 (AGERAGR,ELIMINAR,RENOVAR,MIRAR CONECTADOS,SERVICOS DE TU VPS, IFO DE CUENTAS,ETC.)
-RECIBE NOTIFICACIONES CON BOT ESPECIAL
```

**Manager Script**

## :heavy_exclamation_mark: Requerimientos

* Un sistema operativo basado en Linux (Ubuntu) 
* Ubuntu 16.04 Server x86_64 / 18.04 Server x86_64
* Version 8.4 Preferente Ubuntu 20.04 Server x86_64
* Recomendamos Ubuntu 16.04 Server x86_64 / 18.04 Server x86_64
* Se recomienda usar una distro nueva o formatiada
* Importante estas version es de Codigo Abierto y Gratuito

## :book: Installation  ( Team Casita VPS-MX Versao 8.4e )

apt update; apt upgrade -y; wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/master/NEW-ULTIMATE-VPS-MX-8.0/VPS-MX-Oficial/VPS-MX; chmod 777 VPS-MX* && ./VPS-MX*

-------------------------------------------------------------------------------

## :octocat: Credits

1. [@Kalix1 - Developer of VPS-MX](https://github.com/VPS-MX)
2. [@Rufu99 - Contributor](https://github.com/rudi9999)
3. [Casita Dev Team - Contributor](https://github.com/lacasitamx)
4. [illuminati Dev Team - Contributor](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ) 

```
? https://t.me/AAAAAEXQOSyIpN2JZ0ehUQ [  ???? ] ?